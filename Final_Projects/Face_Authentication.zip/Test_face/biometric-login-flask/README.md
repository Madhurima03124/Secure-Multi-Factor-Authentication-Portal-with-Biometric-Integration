# Biometric log in and sign up concept with Flask

Concept methods to:
- sing in with email and face from a web camera or email and password;
- sing up with email, password and image taken from web camera.

App uses face-recognition library to get face encoding, compare face from a web camera with encoding in database. Frames from the web camera are taken with OpenCV library.

