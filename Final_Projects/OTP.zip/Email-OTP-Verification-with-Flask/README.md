# Email-OTP-Verification-with-Flask
Email OTP Verification using the SMTPLIB module of Python.
